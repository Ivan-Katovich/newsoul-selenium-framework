package com.epam.onliner.elements;

import org.openqa.selenium.By;

import com.epam.fw.object.MyElement;

public final class MultipleElements {
	
	public static final MyElement TOP_LOGO = new MyElement("//img[@class='onliner_logo retina-off']", "webelement");

}
